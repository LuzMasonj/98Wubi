#!/bin/bash 
cp -f ./libyongplatforminputcontextplugin.so /usr/lib/x86_64-linux-gnu/qt5/plugins/platforminputcontexts/
chmod -R 777 /usr/lib/x86_64-linux-gnu/qt5/plugins/platforminputcontexts
chmod +x /usr/lib/x86_64-linux-gnu/qt5/plugins/platforminputcontexts/libyongplatforminputcontextplugin.so
echo "QT5插件迁移成功！"
 
